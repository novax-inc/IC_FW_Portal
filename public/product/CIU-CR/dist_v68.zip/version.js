// version.js
window.APP_VERSION = '2.0-rc68'; // Update this version number when you make changes to your app