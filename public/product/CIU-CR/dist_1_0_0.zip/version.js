// version.js
window.APP_VERSION = '1.0.0'; // Update this version number when you make changes to your app