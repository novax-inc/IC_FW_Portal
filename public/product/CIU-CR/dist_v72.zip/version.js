// version.js
window.APP_VERSION = '2.0-rc72'; // Update this version number when you make changes to your app